/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20180817;

/**
 *
 * @author yoda
 */
public class Variaveis3 {
    public static void main(String[] args) {
        int i = (int)3.14159;
        System.out.println("valor de i: "+i);
        float f = 3.14159f;
        System.out.println("Valor de f: "+f);
        
//        int j = 6000000000000;
//        System.out.println("Valor de j: "+j);
        float g = 6e12f;
        System.out.println("Valor de g: "+g);
    }
}
















