/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20180817;

/**
 *
 * @author yoda
 */
public class Incremento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        int a = 3;
//        int b = a++;
////        int b = a;
////        a++;
//        // b: 3, a: 4
//        System.out.println("a: "+a+"\nb: "+b);
        int a = 3;
        int b = ++a;
//        a++;
//        int b = a;
        // b: 4, a: 4
        System.out.println("a: "+a+"\nb: "+b);
    }
    
}

















