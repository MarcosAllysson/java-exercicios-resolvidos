/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20180817;

/**
 *
 * @author yoda
 */
public class AtribuicaoComposta {
    public static void main(String[] args) {
        int a = 4;
        int b = 7;
        a += b; // a = a+b;
        System.out.println("Valor de a: "+a);
    }
}








