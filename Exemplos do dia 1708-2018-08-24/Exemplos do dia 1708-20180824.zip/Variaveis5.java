/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20180817;

/**
 *
 * @author yoda
 */
public class Variaveis5 {
    public static void main(String[] args) {
//        int a = 5;
//        int b = 0;
//        int c = a/b;
//        System.out.println("A divisão deu:"+c);
        float a = 5;
        float b = 0;
        float c = a/b;
        System.out.println("A divisão deu:"+c);
        float d = a%b;
        System.out.println("O resto da divisão deu: "+d);
        float e = a/b;
        float f = c/e;
        System.out.println("A nova divisão deu: "+f);
        
        double g = -1;
        double h = Math.sqrt(-1);
        System.out.println("O valor de h: "+h);
        
//        float f = 0.2f;
//        for (int i = 0; i < 10; i++) {
//            f *= f;
//            System.out.println("Valor de f: "+f);
//        }
        
    }
}










