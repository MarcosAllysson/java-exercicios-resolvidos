/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20180817;

/**
 *
 * @author yoda
 */
public class Condicionais2 {
    public static void main(String[] args) {
        int a = 41;
        int b = 6;
        int z = (a>b) ? a: b;
//        int z;
//        if (a > b) {
//            z = a;
//        } else {
//            z = b;
//        }
        System.out.println("O maior é "+z);
        
        
    }
}
















