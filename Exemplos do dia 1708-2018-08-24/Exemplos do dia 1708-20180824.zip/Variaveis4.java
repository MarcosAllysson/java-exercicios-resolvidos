/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20180817;

/**
 *
 * @author yoda
 */
public class Variaveis4 {
    public static void main(String[] args) {
        double d = 40000000000000000.0;
        System.out.println("Valor de d: "+d);
        double e = d+1;
        System.out.println("Valor de e: "+e);
        if(d == e) {
            System.out.println("São iguais.");
        } else {
            System.out.println("São diferentes.");
        }
    }
}














