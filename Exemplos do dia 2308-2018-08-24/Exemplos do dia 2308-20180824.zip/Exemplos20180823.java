/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20180823;

import javax.swing.JOptionPane;

/**
 *
 * @author yoda
 */
public class Exemplos20180823 {

    public static void main(String[] args) {
        for(int i = 1; i <= 10; i++) {
            System.out.println(i);
        }
    }
    
}



