/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.FlowLayout;
import javax.swing.*;

/**
 *
 * @author yoda
 */
public class PrimeiraJanela extends JFrame {
    JLabel rotulo;
    JTextField campo;
    JButton botao;
    JTextArea area;
    
    public PrimeiraJanela () {
        setLayout(new FlowLayout());
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        rotulo = new JLabel("Escreva algo:");
        add(rotulo);
        campo = new JTextField(10);
        add(campo);
        area = new JTextArea(5, 10);
        add(area);
        botao = new JButton("Processar");
        add(botao);
    }
    
    public static void main(String[] args) {
        PrimeiraJanela janela = new PrimeiraJanela();
        janela.setSize(300,400);
        janela.setVisible(true);
    }
}
