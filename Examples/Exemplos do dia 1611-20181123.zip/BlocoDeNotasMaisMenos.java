/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20181116;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 *
 * @author yoda
 */
public class BlocoDeNotasMaisMenos extends JFrame {
    JTextArea area;
    JScrollPane painelComBarraDeRolagem;
    JMenuBar barraDeMenu;
    JMenu menuArquivo;
    JMenu menuAjuda;
    JMenuItem menuArquivoNovo;
    JMenuItem menuArquivoAbrir;
    JMenuItem menuArquivoSalvar;
    JMenuItem menuArquivoSalvarComo;
    JMenuItem menuArquivoSair;
    JMenuItem menuAjudaSobre;
    File arquivo;
    boolean alterado;
    
    public BlocoDeNotasMaisMenos() {
        super("Bloco de Notas+-"); // Chamada da construtora da super classe, aqui eu estou usando apenas para escrever o título, poderia ser substituída pelo setTitle().
//        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        area = new JTextArea();
        painelComBarraDeRolagem = new JScrollPane(area, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        add(painelComBarraDeRolagem);
        barraDeMenu = new JMenuBar();
        setJMenuBar(barraDeMenu);
        menuArquivo = new JMenu("Arquivo");
        barraDeMenu.add(menuArquivo);
        menuAjuda = new JMenu("Ajuda");
        barraDeMenu.add(menuAjuda);
        menuArquivoNovo = new JMenuItem("Novo");
        menuArquivo.add(menuArquivoNovo);
        menuArquivoAbrir = new JMenuItem("Abrir");
        menuArquivo.add(menuArquivoAbrir);
        menuArquivoSalvar = new JMenuItem("Salvar");
        menuArquivo.add(menuArquivoSalvar);
        menuArquivoSalvarComo = new JMenuItem("Salvar Como...");
        menuArquivo.add(menuArquivoSalvarComo);
        menuArquivoSair = new JMenuItem("Sair");
        menuArquivo.add(menuArquivoSair);
        menuAjudaSobre = new JMenuItem("Sobre");
        menuAjuda.add(menuAjudaSobre);
        menuAjudaSobre.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostraSobre();
            }
        });
        menuArquivoSair.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sair();
            }
        });
        menuArquivoNovo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                novo();
            }
        });
        menuArquivoAbrir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrir();
            }
        });
        menuArquivoSalvar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salvar();
            }
        });
        menuArquivoSalvarComo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salvarComo();
            }
        });
        addWindowListener(new WindowListener() {
            public void windowOpened(WindowEvent e) {
            }
            public void windowClosing(WindowEvent e) {
                sair();
            }
            public void windowClosed(WindowEvent e) {
            }
            public void windowIconified(WindowEvent e) {
            }
            public void windowDeiconified(WindowEvent e) {
            }
            public void windowActivated(WindowEvent e) {
            }
            public void windowDeactivated(WindowEvent e) {
            }
        });
        area.addKeyListener(new KeyListener() {
            public void keyTyped(KeyEvent e) {
                alterado = true;
            }
            public void keyPressed(KeyEvent e) {
            }
            public void keyReleased(KeyEvent e) {
            }
        });
    }

    void novo() {
        if(alterado) {
            int opcao = JOptionPane.showOptionDialog(this, "Você quer salvar antes de criar novo?", "Aviso", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE, null, null, null);
            if(opcao == JOptionPane.YES_OPTION) {
                salvarComo();
            } else if(opcao == JOptionPane.NO_OPTION) {
                System.exit(0); // Fecha o programa inteiro.
            } else if(opcao == JOptionPane.CANCEL_OPTION || opcao == JOptionPane.CLOSED_OPTION) {
                return;
            }
        } 
        arquivo = null;
        area.setText("");
        alterado = false;
    }
    
    void sair() {
        if(alterado) { 
            int opcao = JOptionPane.showOptionDialog(this, "Você quer salvar antes de fechar a janela?", "Aviso", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE, null, null, null);
            if(opcao == JOptionPane.YES_OPTION) {
                salvarComo();
        //      dispose(); // Fecha apenas a janela atual.
                System.exit(0); // Fecha o programa inteiro.
            } else if(opcao == JOptionPane.NO_OPTION) {
        //      dispose(); // Fecha apenas a janela atual.
                System.exit(0); // Fecha o programa inteiro.
            } else if(opcao == JOptionPane.CANCEL_OPTION || opcao == JOptionPane.CLOSED_OPTION) {
                // Não faz nada, nem sai.
            }
        } else {
            System.exit(0);
        }
    }
    
    void abrir() {
//        File arquivo = new File("blocodenotas.txt");
        JFileChooser chooser = new JFileChooser();
        int opcao = chooser.showOpenDialog(this);
        if(opcao != JFileChooser.APPROVE_OPTION) {
            return;
        }
        arquivo = chooser.getSelectedFile();
        byte[] arrayDeBytes = new byte[(int)arquivo.length()];
        try {
            FileInputStream fis = new FileInputStream(arquivo);
            fis.read(arrayDeBytes);
            fis.close();
        } catch(FileNotFoundException fnfe) {
            JOptionPane.showMessageDialog(this, "Arquivo não encontrado.");
        } catch(IOException ioe) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro na leitura do arquivo.");
        }
        String texto = new String(arrayDeBytes);
        area.setText(texto);
        alterado = false;
    }
    
    void salvar() {
        if(arquivo == null || !alterado) {
            salvarComo();
            return;
        }
        String texto = area.getText();
        byte[] arrayDeBytes = texto.getBytes();
////        File arquivo = new File("blocodenotas.txt");
//        JFileChooser chooser = new JFileChooser();
//        int opcao = chooser.showSaveDialog(this);
//        if(opcao != JFileChooser.APPROVE_OPTION) {
//            return;
//        }
//        File arquivo = chooser.getSelectedFile();
        try{
            FileOutputStream fos = new FileOutputStream(arquivo); // Sobrescreve
//            FileOutputStream fos = new FileOutputStream(arquivo, true);// Acrescenta no final
            fos.write(arrayDeBytes);
            fos.close();
        } catch(FileNotFoundException fnfe) {
            JOptionPane.showMessageDialog(this, "Arquivo não encontrado.");
        } catch(IOException ioe) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro na leitura do arquivo.");
        }
        alterado = false;
    }
    void salvarComo() {
        String texto = area.getText();
        byte[] arrayDeBytes = texto.getBytes();
//        File arquivo = new File("blocodenotas.txt");
        JFileChooser chooser = new JFileChooser();
        int opcao = chooser.showSaveDialog(this);
        if(opcao != JFileChooser.APPROVE_OPTION) {
            return;
        }
        arquivo = chooser.getSelectedFile();
        try{
            FileOutputStream fos = new FileOutputStream(arquivo); // Sobrescreve
//            FileOutputStream fos = new FileOutputStream(arquivo, true);// Acrescenta no final
            fos.write(arrayDeBytes);
            fos.close();
        } catch(FileNotFoundException fnfe) {
            JOptionPane.showMessageDialog(this, "Arquivo não encontrado.");
        } catch(IOException ioe) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro na leitura do arquivo.");
        }
        alterado = false;
    }
    
    void mostraSobre() {
        JOptionPane.showMessageDialog(this, "Programa Bloco de Notas +-\n\nversão 0.03b\nDesenvolvido pela turma de Sistemas para Internet.\n\nNenhum direito reservado.");
    }
    
    public static void main(String[] args) {
        BlocoDeNotasMaisMenos janela = new BlocoDeNotasMaisMenos();
        janela.setSize(400, 500);
        janela.setVisible(true);
    }
}
