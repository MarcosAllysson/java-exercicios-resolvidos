/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20181116;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 *
 * @author yoda
 */
public class BlocoDeNotasMenosMenos extends JFrame {
    JTextArea area;
    JScrollPane painelComBarraDeRolagem;
    JMenuBar barraDeMenu;
    JMenu menuArquivo;
    JMenu menuAjuda;
    JMenuItem menuArquivoNovo;
    JMenuItem menuArquivoAbrir;
    JMenuItem menuArquivoSalvar;
    JMenuItem menuArquivoSair;
    JMenuItem menuAjudaSobre;
    
    public BlocoDeNotasMenosMenos() {
        super("Bloco de Notas--"); // Chamada da construtora da super classe, aqui eu estou usando apenas para escrever o título, poderia ser substituída pelo setTitle().
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        area = new JTextArea();
        painelComBarraDeRolagem = new JScrollPane(area, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        add(painelComBarraDeRolagem);
        barraDeMenu = new JMenuBar();
        setJMenuBar(barraDeMenu);
        menuArquivo = new JMenu("Arquivo");
        barraDeMenu.add(menuArquivo);
        menuAjuda = new JMenu("Ajuda");
        barraDeMenu.add(menuAjuda);
        menuArquivoNovo = new JMenuItem("Novo");
        menuArquivo.add(menuArquivoNovo);
        menuArquivoAbrir = new JMenuItem("Abrir");
        menuArquivo.add(menuArquivoAbrir);
        menuArquivoSalvar = new JMenuItem("Salvar");
        menuArquivo.add(menuArquivoSalvar);
        menuArquivoSair = new JMenuItem("Sair");
        menuArquivo.add(menuArquivoSair);
        menuAjudaSobre = new JMenuItem("Sobre");
        menuAjuda.add(menuAjudaSobre);
        menuAjudaSobre.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostraSobre();
            }
        });
        menuArquivoSair.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
//                dispose(); // Fecha apenas a janela atual.
                System.exit(0); // Fecha o programa inteiro.
            }
        });
        menuArquivoNovo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                area.setText("");
            }
        });
        menuArquivoAbrir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrir();
            }
        });
        menuArquivoSalvar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                salvar();
            }
        });
    }

    void abrir() {
//        File arquivo = new File("blocodenotas.txt");
        JFileChooser chooser = new JFileChooser();
        int opcao = chooser.showOpenDialog(this);
        if(opcao != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File arquivo = chooser.getSelectedFile();
        byte[] arrayDeBytes = new byte[(int)arquivo.length()];
        try {
            FileInputStream fis = new FileInputStream(arquivo);
            fis.read(arrayDeBytes);
            fis.close();
        } catch(FileNotFoundException fnfe) {
            JOptionPane.showMessageDialog(this, "Arquivo não encontrado.");
        } catch(IOException ioe) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro na leitura do arquivo.");
        }
        String texto = new String(arrayDeBytes);
        area.setText(texto);
    }
    
    void salvar() {
        String texto = area.getText();
        byte[] arrayDeBytes = texto.getBytes();
//        File arquivo = new File("blocodenotas.txt");
        JFileChooser chooser = new JFileChooser();
        int opcao = chooser.showSaveDialog(this);
        if(opcao != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File arquivo = chooser.getSelectedFile();
        try{
            FileOutputStream fos = new FileOutputStream(arquivo); // Sobrescreve
//            FileOutputStream fos = new FileOutputStream(arquivo, true);// Acrescenta no final
            fos.write(arrayDeBytes);
            fos.close();
        } catch(FileNotFoundException fnfe) {
            JOptionPane.showMessageDialog(this, "Arquivo não encontrado.");
        } catch(IOException ioe) {
            JOptionPane.showMessageDialog(this, "Ocorreu um erro na leitura do arquivo.");
        }
    }
    
    void mostraSobre() {
        JOptionPane.showMessageDialog(this, "Programa Bloco de Notas --\n\nversão 0.02a\nDesenvolvido pela turma de Sistemas para Internet.\n\nNenhum direito reservado.");
    }
    
    public static void main(String[] args) {
        BlocoDeNotasMenosMenos janela = new BlocoDeNotasMenosMenos();
        janela.setSize(400, 500);
        janela.setVisible(true);
    }
}
