/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20181116;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 *
 * @author yoda
 */
public class ExemploMenu extends JFrame {
    JButton botao;
    JMenuBar barraDeMenu;
    JMenu menuArquivo;
    JMenu menuEditar;
    JMenu menuAjuda;
    JMenuItem menuArquivoNovo;
    JMenuItem menuArquivoAbrir;
    JMenuItem menuArquivoSalvar;
    JMenuItem menuEditarCopiar;
    JMenuItem menuEditarColar;
    JMenuItem menuAjudaSobre;
    
    public ExemploMenu() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        botao = new JButton("Faz nada");
        add(botao);
        barraDeMenu = new JMenuBar();
        setJMenuBar(barraDeMenu);
        menuArquivo = new JMenu("Arquivo");
        barraDeMenu.add(menuArquivo);
        menuEditar = new JMenu("Editar");
        barraDeMenu.add(menuEditar);
        menuAjuda = new JMenu("Ajuda");
        barraDeMenu.add(menuAjuda);
        menuArquivoNovo = new JMenuItem("Novo");
        menuArquivo.add(menuArquivoNovo);
        menuArquivoAbrir = new JMenuItem("Abrir");
        menuArquivo.add(menuArquivoAbrir);
        menuArquivoSalvar = new JMenuItem("Salvar");
        menuArquivo.add(menuArquivoSalvar);
        menuEditarCopiar = new JMenuItem("Copiar");
        menuEditar.add(menuEditarCopiar);
        menuEditarColar = new JMenuItem("Colar");
        menuEditar.add(menuEditarColar);
        menuAjudaSobre = new JMenuItem("Sobre");
        menuAjuda.add(menuAjudaSobre);
        menuArquivoNovo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Você clicou no novo.");
            }
        });
        menuArquivoAbrir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Você clicou no abrir.");
            }
        });
        menuArquivoSalvar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Você clicou no salvar.");
            }
        });
        menuEditarCopiar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Você clicou no copiar.");
            }
        });
        menuEditarColar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Você clicou no colar.");
            }
        });
        menuAjudaSobre.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Você clicou no sobre.");
            }
        });
    }
    
    
    public static void main(String[] args) {
        ExemploMenu janela = new ExemploMenu();
        janela.setSize(300, 200);
        janela.setVisible(true);
    }
}
