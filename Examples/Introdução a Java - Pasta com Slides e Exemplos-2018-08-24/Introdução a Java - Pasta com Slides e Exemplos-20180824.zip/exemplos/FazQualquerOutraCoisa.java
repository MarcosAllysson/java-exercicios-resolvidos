import javax.swing.JOptionPane;

public class FazQualquerOutraCoisa {
    
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Qualquer outra coisa!");
    }
    
}
