public class FazNada {
    
    public static void main(String[] args) {
    }
    
}
