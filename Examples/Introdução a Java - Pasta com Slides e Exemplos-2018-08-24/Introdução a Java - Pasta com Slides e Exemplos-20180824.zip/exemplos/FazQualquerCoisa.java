public class FazQualquerCoisa {
    
    public static void main(String[] args) {
        System.out.println("Qualquer coisa");
    }
    
}
