/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20181122;

import javax.swing.JOptionPane;

/**
 *
 * @author yoda
 */
public class T2Q1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Receber a matriz do usuário.
        int m = Integer.parseInt(JOptionPane.showInputDialog("Quantas linhas?"));
        int n = Integer.parseInt(JOptionPane.showInputDialog("Quantas colunas?"));
        int[][] matriz = new int[m][n];
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                matriz[i][j] = Integer.parseInt(JOptionPane.showInputDialog("Qual o valor do próximo elemento?"));
            }
        }
        // Mostrando a matriz na tela:
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                System.out.print(matriz[i][j]+"\t");
            }
            System.out.println("");
        }
        System.out.println("\n");
        //Classificar se é linha
        if(m == 1) {
            System.out.println("É uma matriz linha.");
        }
        //Classificar se é coluna
        if(n == 1) {
            System.out.println("É uma matriz coluna.");
        }
        //Classificar se é quadrada
        if(m == n) {
            System.out.println("É uma matriz quadrada.");
        }
        //Classificar se é nula
        boolean nula = true;
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                if(matriz[i][j] != 0) { // Prova do contrário
                    nula = false;
                }
            }
        }
        if(nula) {
            System.out.println("A matríz é nula.");
        }
        //Classificar se é diagonal
        boolean diagonal = true;
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                if((i!=j)&&(matriz[i][j] != 0)) { // Prova do contrário
                    diagonal = false;
                }
            }
        }
        if((m == n) && diagonal) {
            System.out.println("A matríz é diagonal.");
        }
        //Classificar se é identidade
        boolean identidade = true;
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                if((i!=j)&&(matriz[i][j] != 0)) { // Prova do contrário
                    identidade = false;
                }
                if((i==j)&&(matriz[i][j] != 1)) { // Prova do contrário
                    identidade = false;
                }
            }
        }
        if((m == n) && identidade) {
            System.out.println("A matríz é identidade.");
        }
        //Classificar se é simétrica
        boolean simetrica = true;
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                try {
                    if(matriz[i][j] != matriz[j][i]) { // Prova do contrário
                        simetrica = false;
                    }
                } catch(ArrayIndexOutOfBoundsException aioobe) {
                    simetrica = false;
                }
            }
        }
        if(simetrica) {
            System.out.println("A matríz é simétrica.");
        }
    }
    
}
