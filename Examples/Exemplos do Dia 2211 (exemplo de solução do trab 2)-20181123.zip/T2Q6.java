/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20181122;

import java.util.Random;

/**
 *
 * @author yoda
 */
public class T2Q6 {
    public static void main(String[] args) {
        // Gerar matriz aleatória.
        Random r = new Random();
        int n = r.nextInt(6)+1;
        
        int[][] matriz = new int[n][n];
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < n; j++) {
                matriz[i][j] = r.nextInt(100);
            }
        }
        // Mostrando a matriz na tela:
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < n; j++) {
                System.out.print(matriz[i][j]+"\t");
            }
            System.out.println("");
        }
        System.out.println("\n");
        
        T2Q6 obj = new T2Q6();
        if(obj.determinante(matriz) == 0) {
            System.out.println("A matriz é singular.\nPortanto não possui inversa.");
        } else {
            double[][] matrizInversa = obj.inversa(matriz);
            // Mostrando a matriz na tela:
            for(int i = 0; i < n; i++) {
                for(int j = 0; j < n; j++) {
                    System.out.print(matrizInversa[i][j]+"\t");
                }
                System.out.println("");
            }
            System.out.println("\n");
        }
    }
    
    double[][] inversa(int[][] matriz) {
        int ordem = matriz.length;
        double det = determinante(matriz);
        double[][] matrizInversa = new double[ordem][ordem];
        for(int i = 0; i < ordem; i++) {
            for(int j = 0; j < ordem; j++) {
                matrizInversa[j][i] = determinante(reduzMatriz(matriz, i, j))*Math.pow(-1, i+j)/det;
            }
        }
        return matrizInversa;
    }
    
    
    double determinante(int[][] matriz) {
        int ordem = matriz.length;
        // Caso base
        if(ordem == 1) {
            return matriz[0][0];
        }
        if(ordem == 0) {
            return 1;
        }
        // Relação de recorrência
        double det = 0;
        for(int i = 0; i < ordem; i++) {
             det += matriz[0][i] * Math.pow(-1, 0+i) * determinante(reduzMatriz(matriz, 0, i));
        }
        return det;
    }
    
    int[][] reduzMatriz(int[][] matrizOriginal, int l, int c) {
        int ordem = matrizOriginal.length;
        int[][] matrizReduzida = new int[ordem-1][ordem-1];
        for(int i = 0; i < ordem-1; i++) {
            for(int j = 0; j < ordem-1; j++) {
                if((i < l) && (j < c)) {
                    matrizReduzida[i][j] = matrizOriginal[i][j];
                } else if((i < l) && (j >= c)) {
                    matrizReduzida[i][j] = matrizOriginal[i][j+1];
                } else if((i >= l) && (j < c)) {
                    matrizReduzida[i][j] = matrizOriginal[i+1][j];
                } else if((i >= l) && (j >= c)) {
                    matrizReduzida[i][j] = matrizOriginal[i+1][j+1];
                }
            }
        }
        return matrizReduzida;
    }
}
