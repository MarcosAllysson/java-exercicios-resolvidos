/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20181122;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author yoda
 */
public class T2Q2 {
    public static void main(String[] args) {
        // Gerar matriz aleatória.
        Random r = new Random();
        int m = r.nextInt(6)+1;
        int n = r.nextInt(6)+1;
        int[][] matriz = new int[m][n];
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                matriz[i][j] = r.nextInt(100);
            }
        }
        // Mostrando a matriz na tela:
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                System.out.print(matriz[i][j]+"\t");
            }
            System.out.println("");
        }
        System.out.println("\n");
        
        int[][] transposta = new int[n][m];
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < m; j++) {
                transposta[i][j] = matriz[j][i];
            }
        }
        // Mostrando a matriz na tela:
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < m; j++) {
                System.out.print(transposta[i][j]+"\t");
            }
            System.out.println("");
        }
        System.out.println("\n");
    }
}
