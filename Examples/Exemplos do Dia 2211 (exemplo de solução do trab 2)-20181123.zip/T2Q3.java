/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplos20181122;

import java.util.Random;

/**
 *
 * @author yoda
 */
public class T2Q3 {
    public static void main(String[] args) {
        // Gerar matriz aleatória.
        Random r = new Random();
        int m = r.nextInt(6)+1;
        int n = r.nextInt(6)+1;
        int[][] matrizA = new int[m][n];
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                matrizA[i][j] = r.nextInt(100);
            }
        }
        // Mostrando a matriz na tela:
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                System.out.print(matrizA[i][j]+"\t");
            }
            System.out.println("");
        }
        System.out.println("\n");
        
        int[][] matrizB = new int[m][n];
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                matrizB[i][j] = r.nextInt(100);
            }
        }
        // Mostrando a matriz na tela:
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                System.out.print(matrizB[i][j]+"\t");
            }
            System.out.println("");
        }
        System.out.println("\n");

        int[][] matrizC = new int[m][n];
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                matrizC[i][j] = matrizA[i][j]+matrizB[i][j];
            }
        }
        // Mostrando a matriz na tela:
        for(int i = 0; i < m; i++) {
            for(int j = 0; j < n; j++) {
                System.out.print(matrizC[i][j]+"\t");
            }
            System.out.println("");
        }
        System.out.println("\n");
    }
}
